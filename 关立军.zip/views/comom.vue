<template>
    <div>

    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="less" >
 .ivu-rate{
   font-size: 16px;
 }
</style>