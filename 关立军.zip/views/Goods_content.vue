<template>
   <div>
       <!-- 商品详情页面 -->
       <p>商品详情页面</p>
   </div>
</template>

<script>
export default {

}
</script>

<style>

</style>